<?php

// Enable error reporting and display errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Your PHP code goes here



// db_connect.php
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "cars";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Set initial SQL query
$sql = "SELECT * FROM car_listings";

// Apply filters if provided
if (isset($_GET['minPrice'])) {
    $minPrice = floatval($_GET['minPrice']);
    $sql .= " WHERE price >= $minPrice";
}

if (isset($_GET['maxPrice'])) {
    $maxPrice = floatval($_GET['maxPrice']);
    if (strpos($sql, 'WHERE') !== false) {
        $sql .= " AND price <= $maxPrice";
    } else {
        $sql .= " WHERE price <= $maxPrice";
    }
}

// Execute query
$result = $conn->query($sql);

// Store results in array
$carListings = array();
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $carListings[] = $row;
  }
}

// Output JSON
header('Content-Type: application/json');
echo json_encode($carListings);

$conn->close();
?>
