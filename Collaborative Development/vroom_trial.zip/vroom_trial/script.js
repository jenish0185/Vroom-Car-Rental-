// script.js

// Fetch car listings from PHP script
fetch('filter.php')
  .then(response => response.json())
  .then(data => {
    // Loop through each car listing and create HTML panels
    data.forEach(car => {
      // Create HTML panel for each car listing
      const carPanel = document.createElement('div');
      carPanel.classList.add('car-panel');
      carPanel.innerHTML = `
        <img src="${car.picture}" alt="${car.brand}">
        <h2>${car.brand}</h2>
        <p>Mileage: ${car.mileage}</p>
        <p>Seating Space: ${car.seating_space}</p>
        <p>Luggage Space: ${car.luggage_space}</p>
        <p>Transmission: ${car.transmission}</p>
        <p>Price: ${car.price}</p>
        <p>Premium: ${car.premium ? 'Yes' : 'No'}</p>
      `;
      document.querySelector('.car-listings').appendChild(carPanel);
    });
  })
  .catch(error => console.error('Error fetching car listings:', error));
